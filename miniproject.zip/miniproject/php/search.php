<html lang="en">
<head>
    <title>Interior</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../css/reset.css" type="text/css" media="screen">
    <link rel="stylesheet" href="../css/style.css" type="text/css" media="screen">
    <link rel="stylesheet" href="../css/grid.css" type="text/css" media="screen">   
    <script src="../js/jquery-1.6.2.min.js" type="text/javascript"></script>     
</head>
<body id="page5">
  <!--==============================header=================================-->
    <header>
      <div class="row-1">
          <div class="main">
              <div class="container_12">
                  <div class="grid_12">
                      <nav>
                            <ul class="menu">
                                <li><a href="../index.html">Home</a></li>
                                <li><a href="../information.html">Information</a></li>
                                <li><a href="../designs.html">Designs</a></li>
                                <li><a href="../contacts.html">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="row-2">
          <div class="main">
              <div class="container_12">
                  <div class="grid_9">
                      <h1>
                            <a class="logo" href="index.html">Ho<strong>m</strong>e</a>
                            <span>Design</span>
                        </h1>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>      
    </header>
    
<!-- content -->
    <div id="content">
        <div class="bg-top">
          <div class="bg-top-2">
                <div class="bg">
                    <div class="bg-top-shadow">
                        <div class="main indent">
                            <div class="box indent-left indent-right indent-bottom extra-wrap">
                                <h3 class="color-3 indent-top">RESULTS</h3> 
                                  <?php  
                                    $connect = mysqli_connect("localhost", "root", "", "images");
                                    $name = mysqli_real_escape_string($connect, $_POST['search']);
                                    $query = "SELECT * FROM img_table WHERE name='$name'";  
                                    $result = mysqli_query($connect, $query);  
                                    if ($result->num_rows> 0)
                                    {
                                      echo '<table>';
                                      while($row = mysqli_fetch_array($result))  
                                      {  
                                      echo '  
                                        <tr>  
                                          <td class="text-1">'.$row['description'].' 
                                          </td> </tr><tr>
                                          <td>  
                                            <img src="data:image/jpeg;base64,'.base64_encode($row['image'] ).'"/>  
                                        </td></tr>';  
                                      }
                                      echo '</table>'; 
                                    }
                                    else {
                                      echo '<script type="text/javascript">alert("NO IMAGES FOUND")</script>';  
                                       header('location: ../index.html');
                                    }  
                                     
                                    ?>
                                </div>    
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
        </div>
           
  <!--==============================footer=================================-->
   <footer>
        <div class="main">
          <div class="container_12">
              <div class="wrapper">
                  <div class="grid_4">
                        <div>
                        <p>&copy Copyright Interior - All Rights Reserved</p>
                        </div>
                       
                    </div>
                    <div class="grid_4">
                        <span class="phone-numb"><span>+91</span> 123456789</span>
                    </div>
                    <div class="grid_4">
                        <ul class="list-services">
                            <li><a href="#"></a></li>
                            <li><a class="item-2" href="#"></a></li>
                            <li><a class="item-3" href="#"></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
