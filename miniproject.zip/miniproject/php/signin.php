<?php  
 if($_POST['user'] == 'admin')
	if($_POST['pwd'] == 'admin')
 		header('location: ../login.php');
 	else
 		header('location: ../signin.html');
 else
 	header('location: ../signin.html');		
 		
 ?>