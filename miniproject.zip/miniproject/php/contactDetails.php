<?php
echo "MESSAGE SENDING...";
echo "<br>";
$error=null;
$db = mysqli_connect('localhost', 'root', '', 'contactdetails');
if ($db->connect_error)
  die("Connection failed: " . $conn->connect_error);

  $name = mysqli_real_escape_string($db, $_POST['name']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $phone = mysqli_real_escape_string($db, $_POST['phone']);
  $message = mysqli_real_escape_string($db, $_POST['message']);
if($name and $email and $phone and $message ){
  $sql = "INSERT INTO contact_details (name, email, phone, message) VALUES('$name','$email', '$phone', '$message')";
  mysqli_query($db, $sql);
  echo "<script >alert('MESSAGE SENT')</script>";
}
if($error)
  echo "MESSAGE NOT SENT";
$db->close();
header('location: ../index.html');
?>